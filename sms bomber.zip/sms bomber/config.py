#Config 
admin = 1667734198 #admin Bot id [12345678]
bot_token = '5825725896:AAGfz1jFEA9gBvuV0S-eaxcT8T7C_difbvo' #Token Bot
LOGs = -808803874 #Channel for LOG [-1006845842]
channel = -1231049338 #Channel for Join [@channel] or [-1006845842]
lice = '@ImaDeveloper' #Enter your license

#مود شماره رو بزارید
mdp = 9
#mdp = 09
#mdp = 989
#mdp = +989
# Texts
menutx = """ Welcome to TnT Bot👿 """
viptx = "Vip"


freetx = "Free"


poshtx = "@ImaDeveloper"

vipbuy = "@ImaDeveloper"


help = "@ImaDeveloper"

novip = "you not vip"

mtns = """Start BomBer 👿 ([PHONE])"""#بجای [PHONE] شماره قرار میگیره
jointx = "Join To Chanel"

vipr = 99999999999999
freer = 20